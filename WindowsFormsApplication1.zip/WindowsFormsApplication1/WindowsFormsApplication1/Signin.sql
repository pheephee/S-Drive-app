﻿CREATE TABLE Signin
(
	[Email] VARCHAR(50) NOT NULL, 
    [Password] VARCHAR(50) NOT NULL, 
    CONSTRAINT [PK_Signin] PRIMARY KEY ([Email]) 
)
